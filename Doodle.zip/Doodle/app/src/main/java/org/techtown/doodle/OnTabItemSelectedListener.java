package org.techtown.doodle;

public interface OnTabItemSelectedListener {
    public void onTabSelected(int position);
    public void showFragment2(Note item);
}

